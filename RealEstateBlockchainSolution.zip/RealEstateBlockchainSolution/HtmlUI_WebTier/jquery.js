var GOVT_COMMN_ETHER_PERC = 0.05;

$(document).ready(function () {

    $("#btnSubmit").click(function () {
        var data = {};
        data.SurveyNo = $("#SurveyNo").val();
        data.PlotNo = $("#PlotNo").val();
        data.Area = $("#Area").val();
        data.AreaUnit = $("#AreaUnit").val();
        data.Mesurement = $("#Mesurement").val();
        data.Address = $("#Address").val();
        data.Village = $("#Village").val();
        data.City = $("#City").val();
        data.State = $("#State").val();
        data.Country = $("#Country").val();
        data.Pincode = $("#Pincode").val();
        data.PropertyType = $("#PropertyType").val();
        data.CertificateType = $("#CertificateType").val();
        data.Owner = $("#Owner").val();


        var data_json = JSON.stringify(data);
        //alert(data_json);
        $.ajax({
            type: 'post',
            url: 'http://localhost:3000/postInitialPropertyRegestration',
            data: data_json,
            contentType: "application/json; charset=utf-8",
            success: function (result) {
                alert('Property registered successfully..');
            },
            error: function (error) {
                alert(error);
            }

        });
    });
    $("#btnPredSubmit").click(function(){
        var pincode = $("#PredPincode").val();
        var year = $("#PredYear").val();
    //    alert(year)
        //alert(data_json);
        $.ajax({
            type:'get',
            url:'http://localhost:5000/predictprice?pincode='+pincode+'&year='+year,
            contentType: "application/json; charset=utf-8",
            success:function(result){
                console.log(JSON.stringify(result));
               // alert(JSON.stringify(result));
            //    console.log(JSON.parse(result))
                console.log(result["PredValue"])
                var value = parseInt(result["PredValue"]);
                $('#lblPredictPrice').html(value);
            },
            error:function(error){
                alert(error);
            }
            
        });
    });
    $("#PartyRegBtn").click(function () {
        var data = {};
        data.FirstName = $("#FirstName").val();
        data.LastName = $("#LastName").val();
        data.IdType = $("#IdType").val();
        data.IdNo = $("#IdNo").val();
        data.UserName = $("#UserName").val();
        data.BlockChainWalletAddress = $("#BlockChainWalletAddress").val();
        data.Password = $("#Password").val();
        data.EmailId = $("#EmailId").val();
        data.Address = $("#Address").val();
        data.Village = $("#Village").val();
        data.City = $("#City").val();
        data.State = $("#State").val();
        data.Country = $("#Country").val();
        data.Pincode = $("#Pincode").val();
        var data_json = JSON.stringify(data);
        $.ajax({
            type: 'post',
            url: 'http://localhost:3000/postPartyRegestration',
            data: data_json,
            contentType: "application/json; charset=utf-8",
            success: function (result) {
                alert("Party is Successfully Registered..");
            },
            error: function (error) {
                alert(error);
            }
        });
    });
    $("#UserRegBtn").click(function () {
        var data = {};
        data.UserId = $("#UserId").val();
        data.FirstName = $("#FirstName").val();
        data.LastName = $("#LastName").val();
        data.Password = $("#Password").val();
        data.EmailId = $("#EmailId").val();
        data.BlockChainAddress = $("#BlockChainAddress").val();
        data.Role = $("#Role").val();
        var data_json = JSON.stringify(data);
        //alert(data_json);
        $.ajax({
            type: 'post',
            url: 'http://localhost:3000/postUserRegestration',
            data: data_json,
            contentType: "application/json; charset=utf-8",
            success: function (result) {
                alert("User is Successfully Registered..");
            },
            error: function (error) {
                alert(error);
            }
        });
    });
    $("#RoleRegBtn").click(function () {
        var data = {};
        data.RoleName = $("#RoleName").val();
        data.RoleDescription = $("#RoleDescription").val();
        var data_json = JSON.stringify(data);
        //alert(data_json);
        $.ajax({
            type: 'post',
            url: 'http://localhost:3000/postRoleRegestration',
            data: data_json,
            contentType: "application/json; charset=utf-8",
            success: function (result) {
                alert("Role is Successfully Registered..");
            },
            error: function (error) {
                alert(error);
            }
        });
    });
    $("#PropSaleBtn").click(function () {
        GetPropertysale();
    });
    $("#SubmitSale").click(function () {
        var data = {};
        data.Pincode = $("#PinCode").val();
        data.SurveyNo = $("#SurveyNo").val();
        data.PlotNo = $("#PlotNo").val();
        data.SellerId = $("#OwnerUserName").val();
        data.BuyerId = $("#BuyerUserName").val();
        data.ApproverId = 5;
        var data_json = JSON.stringify(data);
       // alert(data_json);
        $.ajax({
            type: 'post',
            url: 'http://localhost:3000/AproveSales',
            data: data_json,
            contentType: "application/json; charset=utf-8",
            success: function (result) {
                alert(result);
            },
            error: function (error) {
                alert(error);
            }
        });
    });
    $("#propHisbtn").click(function () {
        GetPropertyHistory();
    });
    $("#LoginBtn").click(function () {
        var data = {};
        data.Username = $("#UserName").val();
        data.Password = $("#Password").val();
        var data_json = JSON.stringify(data);
        //alert(data_json);
        $.ajax({
            type: 'post',
            url: 'http://localhost:3000/loginpost',
            data: data_json,
            contentType: "application/json; charset=utf-8",
            success: function (result) {
                alert(result);
            },
            error: function (error) {
                alert(error);
            }
        });
    });

});
function showPropertyForSale(data) {
    //console.log(data);
    console.log(data.recordsets);
    if (data == "Property Not For Sale") {
        alert("This Property Not For Sale");
    }
    else {
        //Property Details
        $("#PropSurveyNo").val(data.recordsets[0][0].SurveyNo);
        $("#PropPlotNo").val(data.recordsets[0][0].PlotNo);
        $("#PropArea").val(data.recordsets[0][0].Area);
        $("#PropAreaUnit").val(data.recordsets[0][0].AreaUnit);
        $("#PropMesurement").val(data.recordsets[0][0].Mesurement);
        $("#PropAddress").val(data.recordsets[0][0].Address);
        $("#PropVillage").val(data.recordsets[0][0].Village);
        $("#PropCity").val(data.recordsets[0][0].City);
        $("#PropState").val(data.recordsets[0][0].State);
        $("#PropCountry").val(data.recordsets[0][0].Country);
        $("#PropPincode").val(data.recordsets[0][0].Pincode);
        $("#PropPropertyType").val(data.recordsets[0][0].PropertyType);
        $("#PropCertificateType").val(data.recordsets[0][0].CertificateType);
        // Owner Details
        $("#OwnerFirstName").val(data.recordsets[1][0].FirstName);
        $("#OwnerLastName").val(data.recordsets[1][0].LastName);
        $("#OwnerIdType").val(data.recordsets[1][0].IDType);
        $("#OwnerIdNo").val(data.recordsets[1][0].IDNo);
        $("#OwnerUserName").val(data.recordsets[1][0].UserID);
        $("#OwnerEmailId").val(data.recordsets[1][0].EmailID);
        $("#OwnerAddress").val(data.recordsets[1][0].Address);
        $("#OwnerVillage").val(data.recordsets[1][0].Village);
        $("#OwnerCity").val(data.recordsets[1][0].City);
        $("#OwnerState").val(data.recordsets[1][0].State);
        $("#OwnerCountry").val(data.recordsets[1][0].Country);
        $("#OwnerPincode").val(data.recordsets[1][0].Pincode);
        //Buyer Details
        //if (data.recordsets[2][0].FirstName) {
        $("#BuyerFirstName").val(data.recordsets[2][0].FirstName);
        $("#BuyerLastName").val(data.recordsets[2][0].LastName);
        $("#BuyerIdType").val(data.recordsets[2][0].IDType);
        $("#BuyerIdNo").val(data.recordsets[2][0].IDNo);
        $("#BuyerUserName").val(data.recordsets[2][0].UserID);
        $("#BuyerEmailId").val(data.recordsets[2][0].EmailID);
        $("#BuyerAddress").val(data.recordsets[2][0].Address);
        $("#BuyerVillage").val(data.recordsets[2][0].Village);
        $("#BuyerCity").val(data.recordsets[2][0].City);
        $("#BuyerState").val(data.recordsets[2][0].State);
        $("#BuyerCountry").val(data.recordsets[2][0].Country);
        $("#BuyerPincode").val(data.recordsets[2][0].Pincode);
        // }
        // else {
        //     alert("No Approved Buyers");
        // }
        //Price Details
        var LandPrize = data.recordsets[3][0].SellingPrice - (data.recordsets[3][0].SellingPrice * GOVT_COMMN_ETHER_PERC);
        $("#LandPrize").val(LandPrize);
        $("#Commission").val(data.recordsets[3][0].SellingPrice * GOVT_COMMN_ETHER_PERC);
        $("#TotalAmount").val(data.recordsets[3][0].SellingPrice);

    }
}
function GetPropertysale() {
    var data = {};
    data.PinCode = $("#PinCode").val();
    data.SurveyNo = $("#SurveyNo").val();
    data.PlotNo = $("#PlotNo").val();
    var data_json = JSON.stringify(data);
    $.ajax({
        type: 'post',
        url: 'http://localhost:3000/salePropertysale',
        data: data_json,
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            showPropertyForSale(result);
        },
        error: function (error) {
            alert("inside error");
        },
        //async: false
    });
}
function SplitYear(year) {
    var year = year.toString();
    var year = year.substring(0, 2) + '-' + year.substring(2, 4) + '-' + year.substring(4, 8);
    return year;
}
function showPropertyHistory(properties) {
    //console.log(data);
    console.log(JSON.stringify(properties));
    console.log("+++++++++++++++++++++++++++++++++++++++++++");
    console.log(JSON.stringify(properties[0][0]));
    console.log("***********************************");
    console.log(JSON.stringify(properties[1][0]));
    console.log(JSON.stringify(properties[1][1]));
    console.log(JSON.stringify(properties[1][2]));
    $("#tblMyProperties tbody tr").remove();
    var table = document.getElementById("tblMyProperties").getElementsByTagName('tbody')[0];
    var row = table.insertRow(table.rows.length);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    var cell3 = row.insertCell(2);
    var cell4 = row.insertCell(3);
    var cell5 = row.insertCell(4);

    cell1.innerHTML = properties[0][0].PropertyId;
    cell2.innerHTML = properties[0][0].SurveyNo;
    cell3.innerHTML = properties[0][0].PlotNo;
    cell4.innerHTML = properties[0][0].Address + ', ' + properties[0][0].Village + ', ' + properties[0][0].City + ', ' + properties[0][0].State + ', ' + properties[0][0].Country + ', ' + properties[0][0].Pincode;
    cell5.innerHTML = properties[0][0].Area + ' ' + properties[0][0].AreaUnit;
    $("#saleshistorytable tbody tr").remove(); 
    var table = document.getElementById("saleshistorytable").getElementsByTagName('tbody')[0];


    for (let i = 0; i < properties[1].length; i++) {
        //alert(JSON.stringify(result.recordset[i]));
        var row = table.insertRow(table.rows.length);
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        var cell3 = row.insertCell(2);
        var cell4 = row.insertCell(3);

        cell1.innerHTML = properties[1][i].FirstName;
        cell2.innerHTML = properties[1][i].LastName;
        cell3.innerHTML = properties[1][i].EmailID;
        cell4.innerHTML = SplitYear(properties[1][i].Year);

    }



}
function GetPropertyHistory() {
    var data = {};
    data.PinCode = $("#PinCode").val();
    data.SurveyNo = $("#SurveyNo").val();
    data.PlotNo = $("#PlotNo").val();
    var data_json = JSON.stringify(data);
    $.ajax({
        type: 'post',
        url: 'http://localhost:3000/GetPropertyHistory',
        data: data_json,
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            showPropertyHistory(result.recordsets);
        },
        error: function (error) {
            alert("inside error");
        },
        //async: false
    });
}

