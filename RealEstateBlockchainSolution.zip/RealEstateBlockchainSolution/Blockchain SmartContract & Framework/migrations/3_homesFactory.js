var Homes = artifacts.require("./Factory.sol")
module.exports = function(deployer) {
  // Use deployer to state migration tasks.
  deployer.deploy(Homes);
};
 