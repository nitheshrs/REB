var Migrations = artifacts.require("./addition.sol");

module.exports = function(deployer) {
  deployer.deploy(Migrations);
};
