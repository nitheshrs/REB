var properties = artifacts.require("./Property.sol")
var prop =  artifacts.require("./Property.sol")
module.exports = function(deployer) {
  // Use deployer to state migration tasks.
  deployer.deploy(properties,213,'0x627306090abaB3A6e1400e9345bC60c78a8BEf57','Harsha');
  // deployer.deploy(prop,13,'0x2932b7A2355D6fecc4b5c0B6BD44cC31df247a2e','Raj');
};


