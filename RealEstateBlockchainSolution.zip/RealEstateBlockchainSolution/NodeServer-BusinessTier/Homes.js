const Web3 = require('web3');
const express = require("express");
const bodyParser = require("body-parser");
const sql = require("mssql");
const session = require('express-session');
const restService = express();

var config = {
  user: 'RohitRajan',
  password: 'Password',
  server: 'IN2220734W2',
  port: 1433,
  database: 'BlockChain'
};

var WalletAdresses;
var PropertyId;
var Year;
var contractAddress;
var PropertyContractAddress;
var contractInstanceForPropHis;
var PropHistory;
var FullData;
var governmentWalletAddress = "0x90Cd2a4EB45A730c4Ba49E9E2309C6266a0931ac";
var GOVT_COMMN_ETHER_PERC = 0.05;

restService.use(bodyParser.urlencoded({ extended: true }));
restService.use(bodyParser.json());
//cors
restService.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});
restService.use(session({ secret: 'theSecretKey', resave: false, saveUninitialized: false }));

// contract address and abi code starts
var contractAddr = '0x994f02c0668384f3ac23c276b96dcfb4b349327b';
var contractABI = [
  {
    "constant": false,
    "inputs": [
      {
        "name": "_userID",
        "type": "uint256"
      },
      {
        "name": "_contract",
        "type": "address"
      },
      {
        "name": "_propertyID",
        "type": "uint256"
      }
    ],
    "name": "setUserInfo",
    "outputs": [],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [
      {
        "name": "_user",
        "type": "uint256"
      }
    ],
    "name": "getUserInfo",
    "outputs": [
      {
        "name": "_add",
        "type": "address[]"
      },
      {
        "name": "prop_id",
        "type": "uint256[]"
      }
    ],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [
      {
        "name": "ownerEthAddress",
        "type": "address"
      },
      {
        "name": "Property_id",
        "type": "uint256"
      },
      {
        "name": "userID",
        "type": "uint256"
      },
      {
        "name": "year",
        "type": "uint256"
      },
      {
        "name": "govtAddr",
        "type": "address"
      }
    ],
    "name": "createChildContracts",
    "outputs": [
      {
        "name": "",
        "type": "address"
      }
    ],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [],
    "name": "getDeployedContracts",
    "outputs": [
      {
        "name": "",
        "type": "address[]"
      }
    ],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

var constantABI = [
  {
    "inputs": [
      {
        "name": "own",
        "type": "address"
      },
      {
        "name": "id",
        "type": "uint256"
      },
      {
        "name": "user_ID",
        "type": "uint256"
      },
      {
        "name": "Registeredyear",
        "type": "uint256"
      },
      {
        "name": "GovtAddr",
        "type": "address"
      }
    ],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": false,
        "name": "buyer",
        "type": "address"
      }
    ],
    "name": "fundsTransferred",
    "type": "event"
  },
  {
    "constant": false,
    "inputs": [],
    "name": "propertyHistory",
    "outputs": [
      {
        "name": "yr",
        "type": "uint256[]"
      },
      {
        "name": "nam",
        "type": "uint256[]"
      }
    ],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [
      {
        "name": "newOwner",
        "type": "address"
      },
      {
        "name": "use_ID",
        "type": "uint256"
      },
      {
        "name": "ownerEthers",
        "type": "uint256"
      },
      {
        "name": "govtEthers",
        "type": "uint256"
      },
      {
        "name": "Transferyear",
        "type": "uint256"
      }
    ],
    "name": "transferOwnership",
    "outputs": [],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [
      {
        "name": "selectedAddress",
        "type": "address"
      },
      {
        "name": "price",
        "type": "uint256"
      }
    ],
    "name": "transferFunds",
    "outputs": [
      {
        "name": "",
        "type": "bool"
      }
    ],
    "payable": true,
    "stateMutability": "payable",
    "type": "function"
  }
];
web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:7545"));
var contractInstance = web3.eth.contract(contractABI).at(contractAddr);
/// contract address and abi code ends

//start:: logic for Converting Hexadecimal to string
function ConvertHexaToString(hex) {
  var str = '';
  for (var i = 0; i < hex.length; i += 2) {
    var v = parseInt(hex.substr(i, 2), 16);
    if (v) str += String.fromCharCode(v);
  }
  return str;
}
//End:: logic for Converting Hexadecimal to string



restService.post("/CreateParentContract", function (req, res) {
  console.log(req.body.id);
  console.log(req.body.name);
  contractInstance.createChildContracts(req.body.id, req.body.name, { from: web3.eth.accounts[0], gas: 4700000 });
  var ary = contractInstance.getDeployedContracts.call();
  console.log(ary.length);
  for (var i = 0; i <= ary.length - 1; i++) {
    console.log(i + "=" + ary[i]);
  }
  res.send('Data inserted');
});

restService.get("/GetNameFromChildContract", function (req, res) {
  var ary = contractInstance.getDeployedContracts.call();
  var VariableContractInstance;

  var result;
  var name = [];
  console.log("***********************name***************************")
  for (var i = 0; i <= ary.length - 1; i++) {
    VariableContractInstance = web3.eth.contract(constantABI).at(ary[i]);
    result = VariableContractInstance.getName.call();
    name.push(hex2a(result));
    console.log(name);
  }
  res.json(name);

  function hex2a(hex) {
    var str = '';
    for (var i = 0; i < hex.length; i += 2) {
      var v = parseInt(hex.substr(i, 2), 16);
      if (v) str += String.fromCharCode(v);
    }
    return str;
  }


});

restService.get("/getInitialPropertyRegestration", function (req, res) {

  sql.connect(config, function (err) {
    console.log("*********************************************************************************")
    if (err) console.log(err);
    console.log("*********************************************************************************")
    var request = new sql.Request();
    request.execute('sp_InitialPropertyRegistrationSelectAll', function (err, recordsets) {
      if (err) console.log(err);
      console.log(recordsets);
      res.json(recordsets);
      sql.close();
    });
  });
});

restService.get("/getMainPage", function (req, res) {
  res.sendFile('login.html', { root: __dirname })
});

restService.post("/postInitialPropertyRegestration", function (req, res) {
  function first() {
    return new Promise(function (resolve, reject) {

      sql.connect(config, function () {
        var request = new sql.Request();
        request.input('SurveyNo', req.body.SurveyNo);
        request.input('PlotNo', req.body.PlotNo);
        request.input('Area', req.body.Area);
        request.input('AreaUnit', req.body.AreaUnit);
        request.input('Mesurement', req.body.Mesurement);
        request.input('Address', req.body.Address);
        request.input('Village', req.body.Village);
        request.input('City', req.body.City);
        request.input('State', req.body.State);
        request.input('Country', req.body.Country);
        request.input('Pincode', parseInt(req.body.Pincode));
        request.input('PropertyType', req.body.PropertyType);
        request.input('CertificateType', req.body.CertificateType);
        request.input('Owner', req.body.Owner);
        request.execute('sp_InitialPropertyRegistrationInsert', function (err, recordsets) {
          if (err) {
            console.log(err);
            reject(err);
          }
          else {
            WalletAdresses = recordsets.recordset[0].ValletAddr;
            PropertyId = recordsets.recordset[0].PropertyId;
            Year = (recordsets.recordset[0].Year).toString();
            sql.close();
            // console.log(recordsets);
            console.log("inside promise");
            console.log(WalletAdresses);
            console.log(PropertyId);
            console.log(Year);
            resolve(WalletAdresses);
          }

        });
      });

    });
  }

  var startpromise = first();

  startpromise.then(function () {
    console.log("inside then");
    console.log(WalletAdresses);
    console.log(PropertyId);
    console.log(Year);
    console.log("before contract call");
    console.log(typeof WalletAdresses);
    console.log(typeof Year);
    contractAddress = contractInstance.createChildContracts.call(WalletAdresses, PropertyId, req.body.Owner, Year, governmentWalletAddress);
    contractInstance.createChildContracts(WalletAdresses, PropertyId, req.body.Owner, Year, governmentWalletAddress, { from: WalletAdresses, gas: 4700000 });
    console.log("after contract call");
    console.log(contractAddress);
    final();
  })

  function final() {
    console.log("inside final db connect");
    sql.connect(config, function () {
      var request = new sql.Request();
      request.input('PropertyId', PropertyId);
      request.input('PropertyContractAddress', contractAddress);
      request.execute('sp_UpdatePropertyContractAddress', function (err, recordsets) {
        if (err) console.log(err);
        console.log("call is done")
        sql.close();
      });
    });
  }

  res.send("successful");
});

restService.post("/postPartyRegestration", function (req, res) {
  sql.connect(config, function () {
    var request = new sql.Request();
    request.input('FirstName', req.body.FirstName);
    request.input('LastName', req.body.LastName);
    request.input('IdType', req.body.IdType);
    request.input('IdNo', req.body.IdNo);
    request.input('UserName', req.body.UserName);
    request.input('BlockChainWalletAddress', req.body.BlockChainWalletAddress);
    request.input('Password', req.body.Password);
    request.input('EmailId', req.body.EmailId);
    request.input('Address', req.body.Address);
    request.input('Village', req.body.Village);
    request.input('City', req.body.City);
    request.input('State', req.body.State);
    request.input('Country', req.body.Country);
    request.input('Pincode', parseInt(req.body.Pincode));
    request.execute('sp_PartyRegistrationInsert', function (err, recordsets) {
      if (err) console.log(err);
      console.log(recordsets);
      console.log("data inserted");
      res.send("data inserted");
      console.log();
      sql.close();
    });
  });
});

restService.post("/postUserRegestration", function (req, res) {
  sql.connect(config, function () {
    var request = new sql.Request();
    request.input('UserId', parseInt(req.body.UserId));
    request.input('FirstName', req.body.FirstName);
    request.input('LastName', req.body.LastName);
    request.input('Password', req.body.Password);
    request.input('EmailId', req.body.EmailId);
    request.input('BlockChainAddress', req.body.BlockChainAddress);
    request.input('Role', req.body.Role);
    request.execute('sp_UserInsert', function (err, recordsets) {
      if (err) console.log(err);
      console.log(recordsets);
      console.log("data inserted");
      res.send("data inserted");

      console.log();
      sql.close();
    });
  });
});

restService.post("/postRoleRegestration", function (req, res) {
  console.log("call reached");
  sql.connect(config, function () {
    var request = new sql.Request();
    request.input('RoleName', req.body.RoleName);
    request.input('RoleDescription', req.body.RoleDescription);
    request.execute('sp_RoleInsert', function (err, recordsets) {
      if (err) console.log(err);
      console.log(recordsets);
      console.log("data inserted");
      res.send("data inserted");

      console.log();
      sql.close();
    });
  });
});

restService.post("/salePropertysale", function (req, res) {
  console.log("inside Propertyforsale");
  sql.connect(config, function () {
    var request = new sql.Request();
    request.input('PinCode', parseInt(req.body.PinCode));
    request.input('SurveyNo', req.body.SurveyNo);
    request.input('PlotNo', req.body.PlotNo);
    request.execute('sp_PropertyForSale', function (err, recordsets) {
      if (err) console.log(err);
      else {
        //console.log(recordsets.returnValue);
        if (!recordsets.returnValue) {
          //console.log("inside if");
          console.log(recordsets);
          res.send(recordsets);
        }
        else {
          console.log("inside else");
          res.send("Property Not For Sale");
        }
      }
      sql.close();
    });
  });
});

restService.post("/AproveSales", function (req, res) {
  console.log("inside ApproveSale");
  function getProperty() {
    return new Promise(function (resolve, reject) {
      console.log("inside ApproveSale promise");
      sql.connect(config, function () {
        var request = new sql.Request();
        request.input('PinCode', parseInt(req.body.Pincode));
        request.input('SurveyNo', req.body.SurveyNo);
        request.input('PlotNo', req.body.PlotNo);
        request.execute('sp_PropertyForSale', function (err, result) {
          if (err) {
            console.log(err);
            reject(err);
          }
          else {

            console.log(JSON.stringify(result));
            console.log("==============");
            console.log(JSON.stringify(result.recordsets[0][0]));
            console.log("==============");
            console.log(JSON.stringify(result.recordsets[1]));
            //var temp = JSON.stringify(result.recordsets[0][0]);
            console.log("+++++++++++++++++++");
            PropertyContractAddress = result.recordsets[0][0].PropertyContractAddress;
            console.log(PropertyContractAddress);
            FullData = result;
            console.log(result.recordsets[0][0].PropertyContractAddress);
            console.log(PropertyContractAddress);
            console.log("Full Data fetched");
            sql.close();
            resolve(PropertyContractAddress);
          }
        });
      });
    });
  }
  var startGetProperty = getProperty();
  startGetProperty.then(function () {
    console.log("calling FundAndOwnershipTransfer");
    FundAndOwnershipTransfer();
  });
  function FundAndOwnershipTransfer() {
    console.log("FundAndOwnershipTransfer reached");
    console.log(FullData);
    console.log("*********************************");
    console.log(FullData.recordsets[3][0].SellingEtherPrice);
    console.log(FullData.recordsets[3][0].SellingEtherPrice);
    var sellingPrice = FullData.recordsets[3][0].SellingEtherPrice;
    var buyerWalletAddress = FullData.recordsets[2][0].BlockChainWalletAddress;
    var commissionToGov = GOVT_COMMN_ETHER_PERC * sellingPrice;
    var priceToOwner = sellingPrice - commissionToGov;
    var buyerUserID = FullData.recordsets[2][0].UserID;
    var currentYear = FullData.recordsets[4][0].CurrentYear;
    console.log("_________________________________");
    console.log(buyerWalletAddress);
    console.log(currentYear);
    console.log("done all assigning");
    contractInstanceForFundTransfer = web3.eth.contract(constantABI).at(PropertyContractAddress);
    //  VariableContractInstance.transferFunds(,,{from:,value: web3.toWei(20, 'ether') });

    var result = contractInstanceForFundTransfer.transferFunds(buyerWalletAddress, sellingPrice, { from: buyerWalletAddress, value: web3.toWei(sellingPrice, 'ether') });
    if (result) {
      contractInstanceForFundTransfer.transferOwnership(buyerWalletAddress, buyerUserID, priceToOwner, commissionToGov, currentYear, { from: governmentWalletAddress, gas: 4700000 });
      savetoDB();
    }
    else {
      console.log("transfer fund failed");
    }
  }
  function savetoDB() {
    console.log("Inside save DB");
    sql.connect(config, function () {
      var request = new sql.Request();
      request.input('PropertyID', parseInt(FullData.recordsets[0][0].PropertyId));
      request.input('NewOwner', parseInt(FullData.recordsets[2][0].UserID));
      request.input('PropSellingID', parseInt(FullData.recordsets[3][0].PropertySellingId));
      request.execute('sp_CommitSales3', function (err, recordsets) {
        if (err) {
          console.log(err);
        }
        else {
          console.log("Successfully transfered property");
          res.send("Successfully transfered property")
          sql.close();
        }
      });
    });
  }
});

//************************ RAJ BLOCK************************************
restService.post("/PostIntrest", function (req, res) {
  sql.connect(config, function () {
    var request = new sql.Request();
    request.input('PropertySellingId', req.body.PropertySellingId);
    request.input('BuyerId', req.body.BuyerId);

    console.log(req.body.PropertySellingID);
    console.log(req.body.BuyerId);
    request.execute('sp_PostIntrest', function (err, recordsets) {
      if (err) {
        console.log(err);
        // reject(err);
      }
      else {
        res.send("Post intrest processed..");
        console.log("Post intrest processed..");
      }
      sql.close();
    });
  });
});

restService.post("/GetPropWhichAreOnSale", function (req, res) {
  sql.connect(config, function () {
    var request = new sql.Request();
    request.input('UserId', req.body.UserId);
    request.execute('sp_GetPropWhichAreOnSale', function (err, recordsets) {
      if (err) {
        console.log(err);
        // reject(err);
      }
      else {
        sql.close();
        res.send(recordsets);
        console.log(recordsets);
      }

    });
  });
});

restService.post("/ApproveProperyBuyFromOwner", function (req, res) {
  sql.connect(config, function () {
    var request = new sql.Request();
    request.input('PropertySellingId', req.body.PropertySellingID);
    request.input('BuyerId', req.body.BuyerId);
    console.log(req.body.PropertySellingID);
    request.execute('sp_approveProperyBuyFromOwner', function (err, recordsets) {
      if (err) {
        console.log(err);
        // reject(err);
      }
      else {
        res.send("Buyer request approved..");
        console.log("Buyer request approved..");
        sql.close();
      }
    });
  });
});

restService.post("/GetNotificationsFroMyProp", function (req, res) {
  sql.connect(config, function () {
    var request = new sql.Request();
    request.input('ownerId', req.body.UserId);
    console.log(req.body.UserId);
    request.execute('sp_myPropBuyingIntrestDetails', function (err, recordsets) {
      if (err) {
        console.log(err);
        // reject(err);
      }
      else {
        res.send(recordsets);
        console.log("success..");
      }
      sql.close();
    });
  });
});

restService.post("/PostPropertyForSale", function (req, res) {
  sql.connect(config, function () {
    var request = new sql.Request();
    request.input('PropertyId', req.body.PropertyId);
    request.input('OwnerId', req.body.OwnerId);
    request.input('SellingPirce', req.body.SellingPirce);
    request.input('SellingEtherPrice', req.body.SellingEtherPrice);
    console.log(req.body.UserId);
    request.execute('sp_PostPropertyForSale', function (err, recordsets) {
      if (err) {
        console.log(err);
        // reject(err);
      }
      else {
        res.send("Property posted for sale successfully..");
        console.log("success..");
      }
      sql.close();
    });
  });
});

restService.post("/GetMyProperties", function (req, res) {
  sql.connect(config, function () {
    var request = new sql.Request();
    request.input('UserId', req.body.UserId);
    console.log(req.body.UserId);
    request.execute('GetMyProperties', function (err, recordsets) {
      if (err) {
        console.log(err);
        // reject(err);
      }
      else {
        sql.close();
        res.send(recordsets);
        console.log(recordsets);
      }

    });
  });
});

restService.post("/GetUserName", function (req, res) {
  sql.connect(config, function () {
    var request = new sql.Request();
    request.input('UserID', req.body.UserID);
    console.log(req.body.UserID);
    request.execute('sp_GetUserName', function (err, recordsets) {
      if (err) {
        console.log(err);
        // reject(err);
      }
      else {
        sql.close();
        res.send(recordsets);
        console.log(recordsets);
      }

    });
  });
});


//***************************** END RAJ BLOCK **************************

//****************************session Implementation start**************
restService.post("/loginpost", function (req, res) {
  username = "Rohit";
  password = "Password";
  if (req.body.Username == username && req.body.Password == password) {
    console.log("login succeful");
    console.log("session variable initilize");
    req.session.user = req.body.Username;
    req.session.flag = true;
    console.log("session name");
    console.log(req.session.flag);
    console.log(req.session.user);
    req.session.save();
    res.send("login succefull");
    //res.redirect('http://localhost:3000/dashboard');
    //res.sendFile('propertysale.html', { root: __dirname })
  }
  else {
    console.log("login failed");
    req.session.flag = false;
    res.send("login failed");
  }
});

restService.get("/dashboard", function (req, res) {
  console.log("you are in dashboard")
  console.log(req.session.user);
  console.log(req.session.flag)
  if (req.session.flag) {
    res.send("you are logged in and redirected to dashboard" + req.session.user);
    console.log("session user name found");
    console.log("you are logged in and redirected to dashboard" + req.session.user);
    //res.sendFile('propertysale.html', { root: __dirname })
  }
  else {
    res.send("you are not autharized");
    console.log("session user name not found");
  }
});
//****************************session Implementation END**************
restService.post("/GetPropertyHistory", function (req, res) {
  function getProperty() {
    return new Promise(function (resolve, reject) {
      console.log("inside get property history");
      sql.connect(config, function () {
        var request = new sql.Request();
        request.input('PinCode', parseInt(req.body.PinCode));
        request.input('SurveyNo', req.body.SurveyNo);
        request.input('PlotNo', req.body.PlotNo);
        request.execute('sp_propHistory', function (err, result) {
          if (err) {
            console.log(err);
            reject(err);
          }
          else {
            //console.log(JSON.stringify(result));
            //console.log(JSON.stringify( result.recordsets[0][0]));
            //console.log(JSON.stringify(result.recordsets[0][0].PropertyContractAddress));
            sql.close();
            PropertyContractAddress = result.recordsets[0][0].PropertyContractAddress;
            console.log(result.recordsets[0][0].PropertyContractAddress);
            console.log(PropertyContractAddress);
            //sql.close();
            resolve(PropertyContractAddress);

          }
        });
      });
    });
  }
  var startGetProperty = getProperty();
  startGetProperty.then(function () {
    console.log("came out of promise")
    contractInstanceForPropHis = web3.eth.contract(constantABI).at(PropertyContractAddress);
    console.log(PropertyContractAddress);
    console.log("addresses Assigned");
    PropHistory = contractInstanceForPropHis.propertyHistory.call({ from: governmentWalletAddress, gas: 4700000 });
    console.log("contract call done");
    var PropYear = PropHistory[0];
    var PropName = PropHistory[1];
    console.log(PropYear.toString());
    console.log(PropName.toString());
    console.log("Before sql call");
    sql.connect(config, function () {
      var request = new sql.Request();
      request.input('PinCode', parseInt(req.body.PinCode));
      request.input('SurveyNo', req.body.SurveyNo);
      request.input('PlotNo', req.body.PlotNo);
      request.input('ALLYEAR', PropYear.toString());
      request.input('ALLID', PropName.toString());
      request.execute('sp_ForHistory', function (err, result) {
        if (err) {
          console.log(err);
        }
        else {
          sql.close();
          console.log("in else");
          console.log(JSON.stringify(result));
          res.send(result);
        }
      });
    });

  });
});

restService.listen(process.env.PORT || 3000, function () {
  console.log("Server up and listening in http://localhost:3000");

});
