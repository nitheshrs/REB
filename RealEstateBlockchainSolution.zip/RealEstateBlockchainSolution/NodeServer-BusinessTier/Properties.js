var owner1 = '0xf17f52151EbEF6C7334FAD080c5704D77216b732';
var owner2 = '0xC5fdf4076b8F3A5357c5E395ab970B5B54098Fef';
var owner3 = '0x821aEa9a577a9b44299B9c15c88cf3087F3b5544';
var name1 = "khandu";
var name2 = "teja";
var name3 = "vikky";

var contractABI = [
  {
    "constant": true,
    "inputs": [],
    "name": "owner",
    "outputs": [
      {
        "name": "",
        "type": "address"
      }
    ],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "name": "id",
        "type": "uint256"
      },
      {
        "name": "own",
        "type": "address"
      },
      {
        "name": "nm",
        "type": "bytes"
      }
    ],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": false,
        "name": "id",
        "type": "uint256"
      },
      {
        "indexed": false,
        "name": "from",
        "type": "bytes"
      },
      {
        "indexed": false,
        "name": "to",
        "type": "bytes"
      }
    ],
    "name": "ownerTransferred",
    "type": "event"
  },
  {
    "constant": false,
    "inputs": [
      {
        "name": "newOwner",
        "type": "address"
      },
      {
        "name": "nm",
        "type": "bytes"
      }
    ],
    "name": "transferOwnership",
    "outputs": [],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  }
]
var contractAddress = '0x4e72770760c011647d4873f60a3cf6cdea896cd8';
var Web3 = require('web3');

var web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));

var contractInstance = web3.eth.contract(contractABI).at(contractAddress);

contractInstance.transferOwnership(owner1,name1, {from : contractInstance.owner.call() });
// contractInstance.transferOwnership(owner2,name2,  {from : contractInstance.owner.call() });
// contractInstance.transferOwnership(owner3,name3,  {from : contractInstance.owner.call() });

var events = contractInstance.ownerTransferred({fromBlock: 0, toBlock:'latest'});
// print(events);
var results = events.get(function(error,logs){
  console.log(logs);
  
}); 
