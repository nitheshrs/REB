const Web3 = require('web3');


var contractAddr = '0x994f02c0668384f3ac23c276b96dcfb4b349327b';
var contractABI = [
  {
    "constant": false,
    "inputs": [
      {
        "name": "_userID",
        "type": "uint256"
      },
      {
        "name": "_contract",
        "type": "address"
      },
      {
        "name": "_propertyID",
        "type": "uint256"
      }
    ],
    "name": "setUserInfo",
    "outputs": [],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": true,
    "inputs": [
      {
        "name": "_user",
        "type": "uint256"
      }
    ],
    "name": "getUserInfo",
    "outputs": [
      {
        "name": "_add",
        "type": "address[]"
      },
      {
        "name": "prop_id",
        "type": "uint256[]"
      }
    ],
    "payable": false,
    "stateMutability": "view",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [
      {
        "name": "ownerEthAddress",
        "type": "address"
      },
      {
        "name": "Property_id",
        "type": "uint256"
      },
      {
        "name": "userID",
        "type": "uint256"
      },
      {
        "name": "year",
        "type": "uint256"
      },
      {
        "name": "govtAddr",
        "type": "address"
      }
    ],
    "name": "createChildContracts",
    "outputs": [
      {
        "name": "",
        "type": "address"
      }
    ],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [],
    "name": "getDeployedContracts",
    "outputs": [
      {
        "name": "",
        "type": "address[]"
      }
    ],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

var constantABI = [
  {
    "inputs": [
      {
        "name": "own",
        "type": "address"
      },
      {
        "name": "id",
        "type": "uint256"
      },
      {
        "name": "user_ID",
        "type": "uint256"
      },
      {
        "name": "Registeredyear",
        "type": "uint256"
      },
      {
        "name": "GovtAddr",
        "type": "address"
      }
    ],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "indexed": false,
        "name": "buyer",
        "type": "address"
      }
    ],
    "name": "fundsTransferred",
    "type": "event"
  },
  {
    "constant": false,
    "inputs": [],
    "name": "propertyHistory",
    "outputs": [
      {
        "name": "yr",
        "type": "uint256[]"
      },
      {
        "name": "nam",
        "type": "uint256[]"
      }
    ],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [
      {
        "name": "newOwner",
        "type": "address"
      },
      {
        "name": "use_ID",
        "type": "uint256"
      },
      {
        "name": "ownerEthers",
        "type": "uint256"
      },
      {
        "name": "govtEthers",
        "type": "uint256"
      },
      {
        "name": "Transferyear",
        "type": "uint256"
      }
    ],
    "name": "transferOwnership",
    "outputs": [],
    "payable": false,
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "constant": false,
    "inputs": [
      {
        "name": "selectedAddress",
        "type": "address"
      },
      {
        "name": "price",
        "type": "uint256"
      }
    ],
    "name": "transferFunds",
    "outputs": [
      {
        "name": "",
        "type": "bool"
      }
    ],
    "payable": true,
    "stateMutability": "payable",
    "type": "function"
  }
];

web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:7545"));
var contractInstance = web3.eth.contract(contractABI).at(contractAddr);
contractAddress = contractInstance.createChildContracts.call(web3.eth.accounts[0], 11, 123, 2010,web3.eth.accounts[9]);
    contractInstance.createChildContracts(web3.eth.accounts[0], 11, 123, 2010,web3.eth.accounts[9],{ from: web3.eth.accounts[0], gas: 4700000 });
    console.log("after contract call");
    console.log(contractAddress);

var ary = contractInstance.getDeployedContracts.call();
var VariableContractInstance;
var result;
var name = [];
console.log("***********************name***************************")
for (var i = 0; i <= ary.length - 1; i++) {
  VariableContractInstance = web3.eth.contract(constantABI).at(ary[i]);}
  VariableContractInstance.transferFunds(web3.eth.accounts[1],20,{from:web3.eth.accounts[1],value: web3.toWei(20, 'ether') });
  VariableContractInstance.transferOwnership(web3.eth.accounts[1],100,19,1,2007,{from:web3.eth.accounts[9],gas: 4700000 });
  VariableContractInstance.transferFunds(web3.eth.accounts[2],20,{from:web3.eth.accounts[2],value: web3.toWei(20, 'ether') })
  VariableContractInstance.transferOwnership(web3.eth.accounts[2],900,19,1,2022,{from:web3.eth.accounts[9],gas: 4700000 });
    var PropHistory= VariableContractInstance.propertyHistory.call({ from: web3.eth.accounts[0], gas: 4700000 });
  console.log(typeof PropHistory);
  console.log(PropHistory.toString());
  console.log(PropHistory[0][0].toNumber());
  console.log(PropHistory[0][1].toNumber());
  console.log(PropHistory[0][2].toNumber());
  console.log(PropHistory[1][0].toNumber());
  console.log(PropHistory[1][1].toNumber());
  console.log(PropHistory[1][2].toNumber());
  console.log(typeof PropHistory[0][0].toNumber());
  console.log("****************************");
  var PropYear = PropHistory[0];
  var PropName = PropHistory[1];
  console.log("year and name array");
  console.log(PropYear);
  console.log(PropName);
  console.log("year and name");
  console.log(PropYear[0].toString());
  console.log(PropName[0].toString());


  

