import numpy as np
import pandas as pd
import codecs
import os.path
import csv
import matplotlib.pyplot as plt
from sklearn.cross_validation import train_test_split
from sklearn.linear_model import LinearRegression
from flask import Flask, jsonify, json, request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

default_pin = 560001
my_path1 = os.path.dirname(__file__)
path1 = os.path.join(my_path1, 'TrainingFiles\\'+ str(default_pin) +'.csv')
dataset = pd.read_csv(path1)
x = dataset.iloc[:,:-1].values
y = dataset.iloc[:,1].values

from sklearn.linear_model import LinearRegression
simpleLinearRegression= LinearRegression()
simpleLinearRegression.fit(x,y)
print("simpleLinearRegression loaded for first time")
# fff = simpleLinearRegression.predict(2000)
# print(fff)

def PrepareData(pin):
    my_path = os.path.dirname(__file__)
    path = os.path.join(my_path, 'TrainingFiles\\'+ str(pin) +'.csv')
    print(path)
    dataset = pd.read_csv(path)
    x = dataset.iloc[:,:-1].values
    y = dataset.iloc[:,1].values
    # print(dataset)
    # simpleLinearRegression= LinearRegression()
    simpleLinearRegression.fit(x,y)
    print("Data loaded")
    # print(simpleLinearRegression.predict(3000))
    

# def fetchValue(pred1):
def fetchValue(pin,yr):
    PrepareData(pin)    
    #pred = [[2016,15]]    
    # y_predicat_3 = simpleLinearRegression.predict(pred1).tolist()    
    y_predicat_3 = simpleLinearRegression.predict(yr).tolist()
    print(y_predicat_3[0])
    y_predict = y_predicat_3[0]  #print(type(y_predicat_3.tolist()))
    print(y_predict)    
    return y_predict
        

#@app.route('/predictprice/<int:post_id>&<int:post_val>')
@app.route('/predictprice', methods=['GET'])
def show_post():
    pincode = int(request.args.get('pincode'))
    year =  int(request.args.get('year'))
    # predvalue = [[pincode,year]]
    y_predict = fetchValue(pincode,year)
    if y_predict < 0 :
        y_predict = 0
    # retVal = [{'value' : y_predict}]    
    jsonReturnType = json.dumps(y_predict)
    return jsonify(PredValue=jsonReturnType)
    #return 'Post %f ' % y_predict #% post_val






# @app.route('/login', methods=['GET', 'POST'])
# def login():
#     if request.method == 'POST':
#         do_the_login()
#     else:
#         show_the_login_form()



# @app.route('/')
# def index():
#     return 'Index %d' % val

# @app.route('/user/<username>')
# def show_user_profile(username):
#     return 'User %s' % username


# @app.route('/hello')
# def hello():
#     return 'Hello, World!'